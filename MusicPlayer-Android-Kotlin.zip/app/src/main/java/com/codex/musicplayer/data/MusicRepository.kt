package com.codex.musicplayer.data

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class MusicRepository(private val context: Context, private val dao: MusicDao) {
    private val resolver: ContentResolver get() = context.contentResolver

    fun localTracks() = dao.localTracks()
    fun internetTracks() = dao.internetTracks()
    fun favorites() = dao.favorites()
    fun folders() = dao.folders()
    fun history() = dao.history()

    suspend fun addFolder(uri: Uri) = withContext(Dispatchers.IO) {
        val folder = DocumentFile.fromTreeUri(context, uri) ?: return@withContext
        dao.addFolder(MusicFolder(uri.toString(), folder.name ?: "Музыкальная папка"))
        scanFolder(uri)
    }

    suspend fun removeFolder(uriString: String) = withContext(Dispatchers.IO) {
        dao.deleteFolder(uriString)
        dao.deleteFolderTracks(uriString)
        runCatching {
            resolver.releasePersistableUriPermission(
                Uri.parse(uriString), android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        }
    }

    suspend fun scanAll() = withContext(Dispatchers.IO) {
        // Папки из базы читаются отдельно; вызывающий код использует scanFolder для каждого URI.
    }

    suspend fun scanFolder(treeUri: Uri) = withContext(Dispatchers.IO) {
        val root = DocumentFile.fromTreeUri(context, treeUri) ?: return@withContext
        val found = mutableListOf<MusicTrack>()
        fun walk(dir: DocumentFile) {
            dir.listFiles().forEach { file ->
                if (file.isDirectory) walk(file)
                else if (file.isFile && (file.type?.startsWith("audio/") == true ||
                            file.name.orEmpty().substringAfterLast('.', "").lowercase() in
                            setOf("mp3", "m4a", "aac", "flac", "ogg", "wav", "opus"))) {
                    val name = file.name ?: "Без названия"
                    found += MusicTrack(
                        uri = file.uri.toString(),
                        title = name.substringBeforeLast('.', name),
                        folderUri = treeUri.toString()
                    )
                }
            }
        }
        walk(root)
        found.forEach { dao.upsertTrack(it) }
        if (found.isNotEmpty()) dao.removeMissing(treeUri.toString(), found.map { it.uri })
    }

    suspend fun toggleFavorite(track: MusicTrack) =
        dao.setFavorite(track.id, !track.isFavorite)

    suspend fun saveSearch(query: String) {
        if (query.isNotBlank()) dao.addHistory(SearchHistory(query = query.trim()))
    }
}
