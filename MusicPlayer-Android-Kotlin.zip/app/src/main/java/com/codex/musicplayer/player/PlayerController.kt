package com.codex.musicplayer.player

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.codex.musicplayer.data.MusicTrack

class PlayerController(context: Context) {
    private val player = ExoPlayer.Builder(context).build()
    fun play(track: MusicTrack) {
        val playable = when {
            track.source == "LOCAL" -> track.uri
            !track.previewUrl.isNullOrBlank() -> track.previewUrl
            else -> return
        }
        player.setMediaItem(MediaItem.fromUri(playable))
        player.prepare()
        player.play()
    }
    fun pause() = player.pause()
    fun release() = player.release()
}
