package com.codex.musicplayer.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "music_tracks", indices = [Index("uri", unique = true)])
data class MusicTrack(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val uri: String,
    val title: String,
    val artist: String = "Неизвестный исполнитель",
    val album: String = "",
    val durationMs: Long = 0,
    val source: String = "LOCAL",
    val artworkUrl: String? = null,
    val previewUrl: String? = null,
    val sourceUrl: String? = null,
    val folderUri: String? = null,
    val isFavorite: Boolean = false
)

@Entity(tableName = "music_folders")
data class MusicFolder(
    @PrimaryKey val uri: String,
    val name: String
)

@Entity(tableName = "search_history")
data class SearchHistory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val query: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Dao
interface MusicDao {
    @Query("SELECT * FROM music_tracks WHERE source = 'LOCAL' ORDER BY title COLLATE NOCASE")
    fun localTracks(): Flow<List<MusicTrack>>

    @Query("SELECT * FROM music_tracks WHERE source = 'INTERNET' ORDER BY title COLLATE NOCASE")
    fun internetTracks(): Flow<List<MusicTrack>>

    @Query("SELECT * FROM music_tracks WHERE isFavorite = 1 ORDER BY title COLLATE NOCASE")
    fun favorites(): Flow<List<MusicTrack>>

    @Query("SELECT * FROM music_folders ORDER BY name")
    fun folders(): Flow<List<MusicFolder>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTrack(track: MusicTrack)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addFolder(folder: MusicFolder)

    @Query("DELETE FROM music_folders WHERE uri = :uri")
    suspend fun deleteFolder(uri: String)

    @Query("DELETE FROM music_tracks WHERE folderUri = :uri")
    suspend fun deleteFolderTracks(uri: String)

    @Query("DELETE FROM music_tracks WHERE folderUri = :uri AND uri NOT IN (:presentUris)")
    suspend fun removeMissing(uri: String, presentUris: List<String>)

    @Query("SELECT * FROM search_history ORDER BY createdAt DESC LIMIT 30")
    fun history(): Flow<List<SearchHistory>>

    @Insert
    suspend fun addHistory(item: SearchHistory)

    @Query("UPDATE music_tracks SET isFavorite = :favorite WHERE id = :id")
    suspend fun setFavorite(id: Long, favorite: Boolean)
}

@Database(entities = [MusicTrack::class, MusicFolder::class, SearchHistory::class], version = 1)
abstract class MusicDatabase : RoomDatabase() {
    abstract fun dao(): MusicDao
    companion object {
        @Volatile private var INSTANCE: MusicDatabase? = null
        fun get(context: Context): MusicDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context, MusicDatabase::class.java, "music.db")
                .fallbackToDestructiveMigration().build().also { INSTANCE = it }
        }
    }
}
