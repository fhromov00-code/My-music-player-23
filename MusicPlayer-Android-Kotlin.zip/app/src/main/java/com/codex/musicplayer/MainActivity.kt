package com.codex.musicplayer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import androidx.work.*
import coil.compose.AsyncImage
import com.codex.musicplayer.data.*
import com.codex.musicplayer.player.PlayerController
import com.codex.musicplayer.remote.OnlineMusicRepository
import com.codex.musicplayer.work.LibraryWorker
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private lateinit var db: MusicDatabase
    private lateinit var repo: MusicRepository
    private lateinit var player: PlayerController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = MusicDatabase.get(this)
        repo = MusicRepository(this, db.dao())
        player = PlayerController(this)
        val request = PeriodicWorkRequestBuilder<LibraryWorker>(12, TimeUnit.HOURS).build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "music-library-scan", ExistingPeriodicWorkPolicy.KEEP, request
        )
        setContent { MusicApp(repo, player) }
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicApp(repo: MusicRepository, player: PlayerController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf("Моя музыка") }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<MusicTrack>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val api = remember { OnlineMusicRepository() }
    val local by repo.localTracks().collectAsState(initial = emptyList())
    val online by repo.internetTracks().collectAsState(initial = emptyList())
    val favorites by repo.favorites().collectAsState(initial = emptyList())
    val folders by repo.folders().collectAsState(initial = emptyList())
    val history by repo.history().collectAsState(initial = emptyList())

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        uri?.let {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            runCatching { context.contentResolver.takePersistableUriPermission(it, flags) }
            scope.launch { repo.addFolder(it) }
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Music Player") }, actions = {
                IconButton(onClick = { scope.launch {
                    folders.forEach { repo.scanFolder(Uri.parse(it.uri)) }
                } }) { Icon(Icons.Default.Refresh, "Обновить библиотеку") }
            }) },
            bottomBar = {
                NavigationBar {
                    listOf("Моя музыка", "Интернет", "Поиск", "Избранное").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item, onClick = { tab = item },
                            icon = { Icon(when(item) {
                                "Моя музыка" -> Icons.Default.LibraryMusic
                                "Интернет" -> Icons.Default.Public
                                "Поиск" -> Icons.Default.Search
                                else -> Icons.Default.Favorite
                            }, item) }, label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
                when(tab) {
                    "Моя музыка" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Музыкальные папки", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                            Button(onClick = { folderPicker.launch(null) }) { Text("Добавить папку") }
                        }
                        folders.forEach { folder ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(folder.name, Modifier.weight(1f))
                                IconButton(onClick = { scope.launch { repo.removeFolder(folder.uri) } }) {
                                    Icon(Icons.Default.Delete, "Удалить из библиотеки")
                                }
                            }
                        }
                        HorizontalDivider()
                        TrackList(local, onPlay = player::play, onFavorite = { scope.launch { repo.toggleFavorite(it) } })
                    }
                    "Интернет" -> {
                        Text("Найденные в интернете", style = MaterialTheme.typography.titleMedium)
                        Text("Доступность: превью зависит от источника; полная версия открывается у правообладателя.")
                        TrackList(online, onPlay = player::play, onFavorite = { scope.launch { repo.toggleFavorite(it) } },
                            onOpenSource = { url -> runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } })
                    }
                    "Поиск" -> {
                        OutlinedTextField(
                            value = query, onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(), label = { Text("Песня, исполнитель или альбом") },
                            singleLine = true, trailingIcon = {
                                IconButton(enabled = !loading, onClick = {
                                    if (query.isBlank()) { error = "Введите поисковый запрос"; return@IconButton }
                                    scope.launch {
                                        loading = true; error = null
                                        repo.saveSearch(query)
                                        runCatching { api.search(query) }
                                            .onSuccess { found -> results = found; error = if(found.isEmpty()) "Ничего не найдено" else null }
                                            .onFailure { error = "Ошибка сети: ${it.localizedMessage ?: "попробуйте позже"}" }
                                        loading = false
                                    }
                                }) { Icon(Icons.Default.Search, "Искать") }
                            }
                        )
                        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                        Text("История поиска", style = MaterialTheme.typography.titleSmall)
                        history.take(5).forEach { h -> Text(h.query, Modifier.clickable { query = h.query }) }
                        TrackList(results, onPlay = player::play, onFavorite = { track ->
                            scope.launch {
                                // Интернет-результат хранится в избранном как отдельная сущность.
                                dbTrackFavorite(context, track, repo)
                            }
                        }, onAdd = { track -> scope.launch { dbTrackSave(context, track, repo) } },
                            onOpenSource = { url -> runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } })
                    }
                    else -> TrackList(favorites, onPlay = player::play, onFavorite = { scope.launch { repo.toggleFavorite(it) } })
                }
            }
        }
    }
}

@Composable
fun TrackList(
    tracks: List<MusicTrack>,
    onPlay: (MusicTrack) -> Unit,
    onFavorite: (MusicTrack) -> Unit,
    onAdd: ((MusicTrack) -> Unit)? = null,
    onOpenSource: ((String) -> Unit)? = null
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(tracks, key = { it.uri }) { track ->
            ListItem(
                leadingContent = {
                    if (!track.artworkUrl.isNullOrBlank()) AsyncImage(
                        model = track.artworkUrl, contentDescription = "Обложка",
                        modifier = Modifier.size(52.dp)
                    ) else Icon(Icons.Default.MusicNote, null, Modifier.size(42.dp))
                },
                headlineContent = { Text(track.title, maxLines = 1) },
                supportingContent = {
                    Text("${track.artist} • ${track.album.ifBlank { if(track.source == "LOCAL") "На устройстве" else "Альбом не указан" }}")
                },
                trailingContent = {
                    Row {
                        IconButton(onClick = { onFavorite(track) }) { Icon(Icons.Default.FavoriteBorder, "В избранное") }
                        if (onAdd != null) IconButton(onClick = { onAdd(track) }) {
                            Icon(Icons.Default.Add, "Сохранить в библиотеку")
                        }
                        if (onOpenSource != null && !track.sourceUrl.isNullOrBlank()) {
                            IconButton(onClick = { onOpenSource(track.sourceUrl!!) }) {
                                Icon(Icons.Default.OpenInNew, "Открыть источник")
                            }
                        }
                        IconButton(onClick = { onPlay(track) }) {
                            Icon(Icons.Default.PlayArrow, "Прослушать")
                        }
                    }
                },
                modifier = Modifier.clickable { onPlay(track) }
            )
            if (track.source == "INTERNET") {
                Text(
                    if (track.previewUrl != null) "Доступно короткое превью" else "Только переход к источнику",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.padding(start = 72.dp)
                )
            }
        }
    }
}

// Сохранение онлайн-результата в таблицу, чтобы он оставался доступен в разделах и избранном.
private suspend fun dbTrackSave(context: android.content.Context, track: MusicTrack, repo: MusicRepository) {
    val dao = MusicDatabase.get(context).dao()
    dao.upsertTrack(track)
}
private suspend fun dbTrackFavorite(context: android.content.Context, track: MusicTrack, repo: MusicRepository) {
    val dao = MusicDatabase.get(context).dao()
    dao.upsertTrack(track.copy(isFavorite = true))
}
