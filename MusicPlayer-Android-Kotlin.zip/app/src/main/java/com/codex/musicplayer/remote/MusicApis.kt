package com.codex.musicplayer.remote

import com.codex.musicplayer.BuildConfig
import com.codex.musicplayer.data.MusicTrack
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

data class ITunesResponse(val results: List<ITunesItem> = emptyList())
data class ITunesItem(
    val trackId: Long?, val trackName: String?, val artistName: String?,
    val collectionName: String?, val artworkUrl100: String?, val previewUrl: String?,
    val trackViewUrl: String?
)
interface ITunesApi {
    @GET("search")
    suspend fun search(@Query("term") term: String, @Query("media") media: String = "music",
                       @Query("entity") entity: String = "song", @Query("limit") limit: Int = 40): ITunesResponse
}

data class JamendoResponse(val results: List<JamendoItem> = emptyList())
data class JamendoItem(
    val id: String?, val name: String?, val artist_name: String?,
    val album_name: String?, val album_image: String?, val audio: String?,
    val shareurl: String?, val audiodownload_allowed: Boolean?
)
interface JamendoApi {
    @GET("tracks/")
    suspend fun search(@Query("client_id") clientId: String, @Query("format") format: String = "json",
                       @Query("limit") limit: Int = 30, @Query("search") search: String,
                       @Query("include") include: String = "musicinfo") : JamendoResponse
}

object MusicApiFactory {
    private val retrofit = Retrofit.Builder().addConverterFactory(GsonConverterFactory.create()).build()
    val itunes: ITunesApi = retrofit.newBuilder().baseUrl("https://itunes.apple.com/").build().create(ITunesApi::class.java)
    val jamendo: JamendoApi = retrofit.newBuilder().baseUrl("https://api.jamendo.com/v3.0/").build().create(JamendoApi::class.java)
}

class OnlineMusicRepository {
    suspend fun search(query: String): List<MusicTrack> {
        require(query.isNotBlank()) { "Введите название, исполнителя или альбом" }
        val results = mutableListOf<MusicTrack>()
        val itunes = runCatching { MusicApiFactory.itunes.search(query) }.getOrNull()
        itunes?.results.orEmpty().forEach { item ->
            val id = item.trackId ?: return@forEach
            results += MusicTrack(
                uri = "itunes:$id", title = item.trackName ?: "Без названия",
                artist = item.artistName ?: "Неизвестный исполнитель",
                album = item.collectionName.orEmpty(), source = "INTERNET",
                artworkUrl = item.artworkUrl100, previewUrl = item.previewUrl,
                sourceUrl = item.trackViewUrl
            )
        }
        if (BuildConfig.JAMENDO_CLIENT_ID.isNotBlank()) {
            runCatching { MusicApiFactory.jamendo.search(BuildConfig.JAMENDO_CLIENT_ID, search = query) }
                .getOrNull()?.results.orEmpty().forEach { item ->
                    val id = item.id ?: return@forEach
                    results += MusicTrack(
                        uri = "jamendo:$id", title = item.name ?: "Без названия",
                        artist = item.artist_name ?: "Неизвестный исполнитель",
                        album = item.album_name.orEmpty(), source = "INTERNET",
                        artworkUrl = item.album_image, previewUrl = item.audio,
                        sourceUrl = item.shareurl
                    )
                }
        }
        return results.distinctBy { it.uri }
    }
}
