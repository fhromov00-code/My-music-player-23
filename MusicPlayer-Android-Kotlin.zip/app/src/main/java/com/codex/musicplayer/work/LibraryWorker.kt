package com.codex.musicplayer.work

import android.content.Context
import android.net.Uri
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.codex.musicplayer.data.MusicDatabase
import com.codex.musicplayer.data.MusicRepository
import kotlinx.coroutines.flow.first

class LibraryWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = runCatching {
        val repo = MusicRepository(applicationContext, MusicDatabase.get(applicationContext).dao())
        repo.folders().first().forEach { folder -> repo.scanFolder(Uri.parse(folder.uri)) }
    }.fold({ Result.success() }, { Result.retry() })
}
